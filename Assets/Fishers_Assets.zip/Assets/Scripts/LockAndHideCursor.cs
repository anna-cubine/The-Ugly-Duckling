using UnityEngine;

public class LockAndHideCursor : MonoBehaviour
{
    // Called when the game starts
    void Start()
    {
        // Lock the cursor to the center of the screen
        Cursor.lockState = CursorLockMode.Locked;
        
        // Hide the cursor
        Cursor.visible = false;
    }

    // Update is called once per frame
    void Update()
    {
        // Optionally, you can check if you want to unlock the cursor (e.g., when pressing Escape)
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
        }
    }
}